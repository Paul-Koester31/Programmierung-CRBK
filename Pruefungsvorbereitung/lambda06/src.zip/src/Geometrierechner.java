public interface Geometrierechner<T> {
    double berechne(T flaeche);
}
