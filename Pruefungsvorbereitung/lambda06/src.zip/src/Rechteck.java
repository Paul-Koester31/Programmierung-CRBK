public class Rechteck {
    double a;
    double b;

    public Rechteck(double a, double b){
        this.a=a;
        this.b=b;
    }

    public double getA() {
        return a;
    }

    public double getB() {
        return b;
    }
}
