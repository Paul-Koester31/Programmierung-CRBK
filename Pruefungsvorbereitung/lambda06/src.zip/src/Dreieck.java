public class Dreieck {
    double g;
    double h;

    public Dreieck(double g, double h) {
        this.g = g;
        this.h = h;
    }

    public double getG() {
        return g;
    }

    public double getH() {
        return h;
    }
}
