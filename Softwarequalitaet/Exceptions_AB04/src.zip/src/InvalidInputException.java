public class InvalidInputException extends FahrzeugException{

    public InvalidInputException(String s){
        super(s);
    }
}
