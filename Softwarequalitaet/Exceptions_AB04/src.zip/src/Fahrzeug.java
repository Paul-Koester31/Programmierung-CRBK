public abstract class Fahrzeug {
    public abstract void starten();

    public abstract  void fahren();
}
