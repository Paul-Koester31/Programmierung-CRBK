public class FahrzeugException extends Exception{
    public FahrzeugException(String s){
        System.out.println(s);
    }
}
