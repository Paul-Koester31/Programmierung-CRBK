public class TaschenRechnerException extends Exception{
    public TaschenRechnerException(String s){
        System.out.println(s);
    }
}
