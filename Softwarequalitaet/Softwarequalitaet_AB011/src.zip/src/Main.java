public class Main {
    public static void main(String[] args) {
        try {
            Taschenrechner r = new Taschenrechner();
            r.setVisible(true);
        }catch (TaschenRechnerException e){

        }

    }
}