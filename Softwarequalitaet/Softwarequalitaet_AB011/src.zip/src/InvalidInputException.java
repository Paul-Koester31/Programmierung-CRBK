public class InvalidInputException extends TaschenRechnerException{
    public InvalidInputException(String s) {
        super(s);
    }
}
