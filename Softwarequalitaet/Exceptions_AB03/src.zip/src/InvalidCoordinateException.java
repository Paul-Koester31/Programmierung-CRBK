public class InvalidCoordinateException extends GPSException{
    public InvalidCoordinateException(String s) {
        super(s);
    }
}
