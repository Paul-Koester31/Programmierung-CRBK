public class GPSException extends Exception {
    public GPSException(String s){
        System.out.println(s);
    }
}
