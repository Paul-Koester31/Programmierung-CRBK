public class DivRechner {
    public static double dividiere(double zahl1, double zahl2) throws NumberFormatException,ArithmeticException {
        return zahl1 / zahl2;
    }
}
