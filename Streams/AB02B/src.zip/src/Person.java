import java.io.Serializable;

public abstract class   Person implements Serializable {
    String name;
    String gebDat;
    Double groesse;

}
